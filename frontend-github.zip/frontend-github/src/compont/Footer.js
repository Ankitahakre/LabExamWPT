import React from 'react'

export default function 
() {
  return (
    <div>
        <div class="Footer"></div>
        <b>Museum-Management</b>
    </div>
  )
}
