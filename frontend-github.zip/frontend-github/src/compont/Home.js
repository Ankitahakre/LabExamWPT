import React from 'react'
import Header from './Header'
import Footer from './Footer'
import {outlet}from router-outlet

export default function 
() {
  return (
    <div>
        <Header></Header>
        <outlet></outlet>
        <Footer></Footer>
    </div>
  )
}
