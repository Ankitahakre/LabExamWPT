
var project = createBrowserProject
{
  path="/",
  Element=<App></App>
  children:{
    path:""
   
}
}


